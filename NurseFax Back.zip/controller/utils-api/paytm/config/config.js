var PaytmConfig = {
  mid: "EQQsZP13272943466113",
  key: "gyoUkqKqSczow%du",
  website: "DEFAULT",
};

module.exports.PaytmConfig = PaytmConfig;
