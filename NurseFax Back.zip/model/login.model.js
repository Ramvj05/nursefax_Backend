class Login {
	constructor({ name, password }) {
		this.name = name;
		this.password = password;
	}

	getModel() {
		return this;
	}
}
